package com.example.brandoncs_360_3_2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class smsPermission extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private TextView permissionStatus;
    private Button requestPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.smsverification);

        permissionStatus = findViewById(R.id.permission_status);
        requestPermissionButton = findViewById(R.id.request_permission_button);

        checkSmsPermission();

        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            permissionStatus.setText("Permission Status: Granted");
            enableSmsFeatures();
        } else {
            permissionStatus.setText("Permission Status: Denied");
            disableSmsFeatures();
        }
    }

    private void requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            Toast.makeText(this, "SMS permission is required to send notifications.", Toast.LENGTH_LONG).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatus.setText("Permission Status: Granted");
                enableSmsFeatures();
            } else {
                permissionStatus.setText("Permission Status: Denied");
                disableSmsFeatures();
            }
        }
    }

    private void enableSmsFeatures() {
        Toast.makeText(this, "SMS features enabled.", Toast.LENGTH_SHORT).show();
        // Add logic to start SMS-related services or notifications
    }

    private void disableSmsFeatures() {
        Toast.makeText(this, "SMS features disabled.", Toast.LENGTH_SHORT).show();
        // Adjust app behavior to work without SMS permissions
    }
}