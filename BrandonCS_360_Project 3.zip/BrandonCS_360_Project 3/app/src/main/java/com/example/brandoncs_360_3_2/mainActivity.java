package com.example.brandoncs_360_3_2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class mainActivity extends AppCompatActivity {

    private EditText weightInput, goalWeightInput;
    private TextView resultText;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightInput = findViewById(R.id.weightInput);
        goalWeightInput = findViewById(R.id.goalWeightInput);
        resultText = findViewById(R.id.resultText);
        calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    private void calculateBMI() {
        String weightStr = weightInput.getText().toString();
        String goalWeightStr = goalWeightInput.getText().toString();

        if (!weightStr.isEmpty() && !goalWeightStr.isEmpty()) {
            double weight = Double.parseDouble(weightStr);
            double goalWeight = Double.parseDouble(goalWeightStr);

            double bmi = weight / (1.75 * 1.75); // assuming height is 1.75m
            String message = "Your current BMI is: " + String.format("%.2f", bmi) +
                    "\nGoal: " + goalWeight + "lbs";

            resultText.setText(message);
        } else {
            resultText.setText("Please enter both fields!");
        }
    }


}