package com.example.brandoncs_360_3_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class databaseShell extends SQLiteOpenHelper {

    public static final String databaseName = "WeightTracking.db";
    public static final String tableName = "weight_table";
    public static final String userID = "ID";
    public static final String userWeight = "WEIGHT";
    public static final String Date = "DATE";

    public databaseShell(Context context) {
        super(context, databaseName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + tableName +
                " (ID INTEGER PRIMARY KEY AUTOINCREMENT, WEIGHT REAL, DATE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + tableName);
        onCreate(db);
    }

    public boolean insertData(double weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(userWeight, weight);
        contentValues.put(Date, date);
        long result = db.insert(tableName, null, contentValues);
        return result != -1; // returns true if insert was successful
    }
}